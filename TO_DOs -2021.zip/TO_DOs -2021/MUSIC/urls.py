
from django.urls import path, include
from . import views
urlpatterns = [
    path('',views.M_player,name='music'),
    path('form/', views.Song_form, name='form'),
    path('update-form/<id>', views.edit_Song_form, name='update-form'),
    path('delete-song/<id>/',views.delete_Song, name='delete_Song')
]
