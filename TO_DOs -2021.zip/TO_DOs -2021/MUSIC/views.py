
# Create your views here.
from django.shortcuts import render, redirect,get_object_or_404
from django.http import HttpResponse,HttpResponseRedirect
from django.contrib import messages
from django.http import JsonResponse
import sys
import os
from gtts import gTTS 
from pygame import mixer
import random
# imported our models
from django.core.paginator import Paginator
from . models import Song
from .forms import MyForm

def M_player(request):
    paginator= Paginator(Song.objects.all(),1)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context={"page_obj":page_obj}
    language = 'en'
    mytext=str(page_obj)
    for i in page_obj:
    	mytext="Sound Track is " +i.title + "By"+ i.artist +"......Play and Enjoy...."
    r1 = random.randint(1,10000000)
    r2 = random.randint(1,10000000)
    randfile = str(r2)+"music"+str(r1) +".mp3"
    myobj = gTTS(text=mytext, lang=language, slow=False)
    myobj.save(randfile) 
    mixer.init()
    mixer.music.load(randfile)
    mixer.music.play()
    return render(request,"Music_player.html",context)




 
def Song_form(request):
    
  if request.method == "POST":
    form = MyForm(request.POST,request.FILES)
    if form.is_valid():
      form.save()
      return HttpResponseRedirect('/')
  else:
      form = MyForm()
  return render(request, 'NewSong.html', {'form': form})




def edit_Song_form(request,id):
        obj= get_object_or_404(Song, id=id)
        
        form = MyForm(request.POST,request.FILES, instance= obj)
        context= {'form': form,'obj':obj}

        if form.is_valid():
                obj= form.save(commit= False)

                obj.save()

                messages.success(request, "You successfully updated the Song")

                context= {'form': form,'obj':obj}

                return render(request, 'UpdateSong.html', context)

        else:   
                form = MyForm(instance= obj)
                context= {'form': form,'obj':obj,
                           'error': 'The form was not updated successfully. Please enter in a title and content'}
                return render(request,'UpdateSong.html' , context)


def delete_Song(request, id):
    obj = get_object_or_404(Song, id=id)
    if obj:
        ref = obj.title
        obj.delete()
        data = {'ref': ref, 'message': 'Song'+ ref +'has been deleted'}
        return JsonResponse(data)


