from django import forms
from .models import Song
 
class MyForm(forms.ModelForm):
	def __init__(self, *args, **kwargs):
		super(MyForm, self).__init__(*args, **kwargs)
		self.fields.required=False
	class Meta:
		model = Song
		fields = ["title", "artist","image","audio_file","audio_link","duration"]
		labels = {'title': "Song Title", "artist": "Song Artist ","image":"Thumbnail",
		"audio_file":"Your Song","audio_link":"Audio link","duration":"Duration   "}