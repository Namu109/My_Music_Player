from django.shortcuts import render

# Create your views here.


def Todo_lists(request):

	return render(request,'Todo_list.html')
