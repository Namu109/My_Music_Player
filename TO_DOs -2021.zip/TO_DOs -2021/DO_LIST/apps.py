from django.apps import AppConfig


class DoListConfig(AppConfig):
    name = 'DO_LIST'
