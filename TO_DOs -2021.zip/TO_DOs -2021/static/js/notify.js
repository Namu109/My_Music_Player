$(document).ready(function () {
 $(".comfirm-delete").click(function (e) {
 e.preventDefault();
        var proceed = confirm('Are You sure to delete this Song ?');
        if (proceed == true) {
        var endpoint = $(this).attr('href')
                $.ajax({
                    method: 'GET',
                    url: endpoint,
                    success: function (data) {
                        $.notify({
                            // options
                            title: '<b>Message<b> ',
                            message: data.message,
                        }, {
                            // settings
                            type: 'success',
                            delay: 3000,
                            allow_dismiss: true,

                        });
                        $("#item" + data.ref).hide(1000)

                    },
                    error: function (error_data) {
                        console.log(error_data);
                        $.notify({
                title: '<b>Error</b><br>',
                message: 'Sorry, something gone wrong'
            }, {
                type: 'danger',
                delay: 3000,
            })
                    }
                })
            
        } else {
            e.preventDefault();
            $.notify({
                title: '<b>Action cancelled</b><br>',
                message: 'This one is not <span class="text-danger">Deleted</span>'
            }, {
                type: 'info',
                delay: 3000,
            })
        }
    })


})